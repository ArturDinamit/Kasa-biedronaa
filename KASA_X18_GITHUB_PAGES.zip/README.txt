KASA X18 — GitHub Pages

1. Na GitHub utwórz nowe repozytorium, np. kasa-x18.
2. Wgraj plik index.html z tego ZIP-a do głównego katalogu repozytorium.
3. Wejdź: Settings -> Pages.
4. W sekcji Build and deployment wybierz:
   Source: Deploy from a branch
   Branch: main / (root)
5. Zapisz i poczekaj, aż GitHub pokaże adres https://...github.io/...
6. Otwórz ten adres w Chrome na Androidzie.
7. Włącz X18.
8. W kasie naciśnij „POŁĄCZ DRUKARKĘ X18” i wybierz drukarkę.

Uwaga: połączenie Bluetooth zadziała tylko, jeśli przeglądarka i sam X18 udostępnią zgodny kanał BLE.
